/* Advanced Theory of Computation HW2 
 * Student Name : Jeong Jae Hwan
 * Student ID : 2018-26716
 * Brief : LZ78 Encoding  
 */

#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cstddef>
#include "Tries.h"

#define JAEHWAN_DEBUG

#define CHARACTER_SIZE 128



void LZ78_compress(FILE *_before, FILE *_after)
{	
	Tries *dict = new Tries();
	char one_char;
	int node_num;

	while ( (one_char=fgetc(_before)) != EOF)
	{
		node_num = dict->makeNode(one_char);
		uint8_t ubyte[4];
		if (node_num != -1)
		{
			int i = 0;
			for (; i < 4; i++)
			{
				if (node_num < 64 )
				{
					ubyte[i] = i<<6 | node_num;
					break;
				}
				else
				{
					if(i>=3)
					{
						return;
					}
					ubyte[i] = node_num & 0xFF;
					node_num = node_num >> 8;
				}

			}
			for (; i >= 0; i--)
			{
				fprintf(_after, "%c", ubyte[i]);
			}
			fprintf(_after, "%c", one_char);  
		}
	}
	if (node_num == -1)
	{
		node_num =dict->getCurrentParseNum();
		int i = 0;
		uint8_t ubyte[4];
		for (; i < 4; i++) 
		{
			if (node_num <  64 ) 
			{
				ubyte[i] = (i << 6) | node_num;
				break;
			}
			else 
			{
				if (i >= 3) 
				{
					return;
				}
				ubyte[i] = node_num & 0xFF;
				node_num = node_num >> 8;
			}
		}
		for (; i >= 0; i--)
		{
			fprintf(_after, "%c", ubyte[i]);
		}
	}	
	return;
}



int main(int argc, char *argv[])
{

	if (argc != 3)
	{
		std::cerr << "Usage : ./encoding [target_file] [after_compression]\n";
		exit(-1);
	}

	FILE *before_LZ78 = fopen(argv[1], "r");
	FILE *after_LZ78 = fopen(argv[2], "w");

	if (before_LZ78 == NULL)
	{
		std::cerr << "error : no such file exists\n";
		exit(-1);
	}

	LZ78_compress(before_LZ78, after_LZ78);
	
	fclose(before_LZ78);
	fclose(after_LZ78);

	return 0;

}

