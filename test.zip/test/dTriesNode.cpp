#include "dTriesNode.h"
#include <cstddef>
#include <cstring>
#include <cstdint>

#define CHARACTER_SIZE 128

TriesNode::TriesNode()
{
	parent = nullptr;
	for (int i = 0; i < CHARACTER_SIZE; ++i)
		child[i] = nullptr;
	parseNum = 0;
	str[0] = '\0';
}

TriesNode::TriesNode(TriesNode *_parent, int _num, char _ch)
{
	parent = _parent;
	for (int i = 0; i < CHARACTER_SIZE; ++i)
		child[i] = NULL;
	
	parseNum = _num;
	int len = strlen(parent->str);
	strncpy(str, parent->str, len);
	str[len] = _ch;
	str[len + 1] = '\0';
}

TriesNode* TriesNode::getChild(char _c)
{
	return child[(uint8_t)_c];
}

int TriesNode::getParseNum()
{
	return parseNum;
}

char* TriesNode::getStr()
{
	return str;
}

TriesNode* TriesNode::setChild(int _num, char _c)
{
	child[(uint8_t)_c] = new TriesNode(this, _num, _c);
	return child[(uint8_t)_c];
}