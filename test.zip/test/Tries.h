#ifndef __TRIES_H__

#include "TriesNode.h"


class Tries
{
private:
	TriesNode *root;
	TriesNode *ptr;
	int idx;
public:
	Tries();
	bool isExist(char _c);
	int makeNode(char _target_character);
	TriesNode* getCurrentPtr();
	int getCurrentParseNum();
	int getNodeNum();
};

#endif