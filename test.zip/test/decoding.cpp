#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <cstddef>
#include "dTries.h"

void LZ78_decompress(FILE *_after, FILE *_before)
{
	
	char c;
	Tries *dict = new Tries();
	uint8_t unsign_ch;
	int node_num;

	TriesNode *prevNode = nullptr;
	TriesNode *tempNode = dict->getRoot();

	while ( (c = fgetc(_after) ) != EOF)
	{
		unsign_ch = (uint8_t)c;
		int block_num = (unsign_ch >> 6);

		for (int i = 0; i <= block_num; ++i)
		{
			if (i == 0)
				node_num = unsign_ch & 0x3F;
			else
			{
				node_num = node_num << 8;
				node_num = node_num | unsign_ch;
			}
			c = fgetc(_after);
			unsign_ch = (uint8_t)c;
		}

		prevNode = dict->getTriesNode(node_num);
		dict->makeNode(prevNode, c);

		if (c == EOF)   
		{
			fprintf(_before, "%s", prevNode->getStr());
			break;
		}
		else
		{
			fprintf(_before, "%s%c", prevNode->getStr(), c);
		}

	}

}

int main(int argc, char *argv[])
{
	if (argc != 3)
	{
		std::cerr << "Usage : ./decoding [target_file] [decompressed_file_name]";
		exit(-1);
	}

	FILE *after_LZ78 = fopen(argv[1], "r");
	FILE *before_LZ78 = fopen(argv[2], "w");
	
	LZ78_decompress(after_LZ78, before_LZ78);

	return 0;

}
