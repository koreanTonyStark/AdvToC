#ifndef __DTRIESNODE_H__

#define CHARACTER_SIZE 128

class TriesNode
{
private:
	TriesNode* parent;
	TriesNode* child[CHARACTER_SIZE];
	int parseNum;
	char str[1000];

public:
	TriesNode();
	TriesNode(TriesNode *_parent, int _num, char _ch);
	TriesNode* getChild(char _c);
	int getParseNum();
	char* getStr();
	TriesNode* setChild(int _num, char _c);
};

#endif 