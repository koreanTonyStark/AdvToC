#include "Tries.h"
#include <cstdlib>
#include <cstddef>

#define MAX_NODE 1<<30

Tries::Tries()
{
	this->root = new TriesNode();
	ptr=root;
}


bool Tries::isExist(char _c)
{
	if (ptr->getSpecificNumChild(_c) == nullptr)
		return false;
	else
		return true;
}

int Tries::makeNode(char _target_character)
{
	if (isExist(_target_character))
	{
		ptr = ptr->getSpecificNumChild(_target_character);
		return -1;
	}
	else if (idx>=MAX_NODE)
	{
		
		this->ptr = root;
		return ptr->getParseNum();
	}
	else
	{
		int num = ptr->getParseNum();
		ptr->setChild(_target_character, ++idx);
		ptr = root;
		return num;
	}
}

TriesNode* Tries::getCurrentPtr()
{
	return ptr;
}
int Tries::getCurrentParseNum()
{
	return ptr->getParseNum();
}

int Tries::getNodeNum()
{
	return idx;
}
