#include "TriesNode.h"
#include <cstddef>
#include <cstdint>

TriesNode::TriesNode()
{
	parent = nullptr;
	parseNum = 0;
	for (int i = 0; i < CHARACTER_SIZE; ++i)
		child[i] = nullptr;
}

TriesNode::TriesNode(int _num, TriesNode* _parent)
{
	parent = _parent;
	parseNum = _num;
	for (int i = 0; i < CHARACTER_SIZE; ++i)
		child[i] = nullptr;
}

TriesNode* TriesNode::setChild(char _c, int _parseNum)
{
	child[(uint8_t)_c] = new TriesNode(_parseNum, this);
	return child[(uint8_t)_c];
}

TriesNode* TriesNode::getSpecificNumChild(char _c)
{
	return child[(uint8_t)_c];
}

int TriesNode::getParseNum()
{
	return parseNum;
}