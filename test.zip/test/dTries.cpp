#include "dTries.h"

Tries::Tries()
{
	root = new TriesNode();
	ptr = NULL;
	idx = 0;
	list.push_back(root);
}

TriesNode* Tries::getRoot()
{
	return root;
}

void Tries::makeNode(TriesNode *_node, char _ch)
{
	if (_node->getChild(_ch) == NULL)
	{
		TriesNode *tempNode = _node->setChild(++idx, _ch);
		list.push_back(tempNode);
	}
}

TriesNode* Tries::getTriesNode(int _num)
{
	return list[_num];
}
