#ifndef __DTRIES_H__

#include "dTriesNode.h"
#include <vector>
#include <iostream>

class Tries
{
private:
	TriesNode *root;
	TriesNode *ptr;
	int idx;
	std::vector<TriesNode*> list;
public:
	Tries();
	TriesNode* getRoot();
	void makeNode(TriesNode *_node, char _ch);
	TriesNode* getTriesNode(int _num);

};

#endif